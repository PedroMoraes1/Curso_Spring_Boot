package br.edu.senaisp.spring.Escola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
